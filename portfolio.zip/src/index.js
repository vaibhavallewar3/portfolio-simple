
var typed = new Typed(".typing", {
    strings:["Web Developer.", "Web Designer.", "NodeJS Developer.", "ReactJS Developer."],
    typeSpeed:100,
    backSpeed:60,
    loop:true
});